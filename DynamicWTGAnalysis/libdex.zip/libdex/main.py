import os
from apk import Apk

input_dir = '/home/tmliu/WTG/apks'
for apk in os.listdir(input_dir):
    f = os.path.join(input_dir, apk)
    for dex in Apk(f):
        with open('output/' + 'target.log', 'a+') as fout:
            for class_ in dex.classes:
                for method in class_.methods():
                    if "onCreateOptionsMenu" in method.name() or "onCreateContextMenu" in method.name():
                        print(method.name())
                        splits = method.name()[1:].split(';->')
                        fout.write(splits[0].replace('/','.') + ':' + splits[1] +'\n')